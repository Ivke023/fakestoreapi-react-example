import React, {createContext, useState, useEffect} from 'react'

// create context
export const ProductContext = createContext();

const ProductProvider = ({children}) => {
  // products state
  const [products,setProducts] = useState([]);

  // fetch products from API - useEffect, to do the fetch on page load
  useEffect(() => {
    const fetchProducts = async () => {
      const response = await fetch('https://fakestoreapi.com/products');
      const data = await response.json();

      setProducts(data);
    };

    fetchProducts();
  }, []);
  
  return (
    <ProductContext.Provider value={{products}}>{children}</ProductContext.Provider>
  )
}

export default ProductProvider;